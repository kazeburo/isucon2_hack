$(function () {
    // console.log('ISUCON 2');
});
